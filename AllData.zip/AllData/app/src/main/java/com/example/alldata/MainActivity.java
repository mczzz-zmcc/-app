package com.example.alldata;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.work.Data;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.locks.ReentrantLock;

public class MainActivity extends AppCompatActivity {

    // 控件
    private Button btnStart, btnStop, btnReset, btnDelete;
    private TextView tvData, tvScore;
    private LinearLayout gameContainer, mainContainer;
    private Spinner spinnerFrequency;

    // 游戏相关
    private GameManager gameManager;
    private int totalScore = 0;
    private float currentTouchX = 0f, currentTouchY = 0f;
    private float touchStartX = 0f, touchStartY = 0f;
    private static final int MIN_SLIDE_DISTANCE = 50;

    // 数据收集相关
    private boolean isCollecting = false;
    private List<AllDataModel> dataList = new ArrayList<>();
    private String currentTouchType = "无触摸";
    private String currentTouchDirection = "无";
    private float currentPressure = 0f;
    private float currentSize = 0f;
    private List<long[]> allTouchIntervals = new ArrayList<>();
    private long currentTouchStart = 0;
    private final long FILTER_TIME_T = 150;

    // 核心配置：优化内存阈值（解决OOM和堆积问题）
    private static final int MAX_DATA_SIZE = 800000; // 从200万改为50万条（大幅降低内存占用）
    private static final int BATCH_SAVE_SIZE = 200; // 从500改为200条（加快批次保存频率）
    private boolean isBatchSaving = false; // 避免并发保存

    // 唯一文件标识（用于绑定同一收集会话的文件）
    private String collectSessionId; // 格式：yyyyMMdd_HHmmss（收集开始时间）
    private String targetCsvPath; // 目标CSV文件路径
    private String crashLogPath; // 崩溃日志保存路径

    // 传感器相关
    private SensorManager sensorManager;
    private Sensor accelerometer, gyroscope, magnetometer;
    private int sensorDelay;
    private boolean isSensorRegistered = false;
    private final int[] FIXED_HZ_OPTIONS = {5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
    private List<Integer> supportedHzList = new ArrayList<>();
    private int selectedHz = 50;

    // 线程安全控制：升级为ReentrantLock（比synchronized更灵活，支持中断）
    private final ReentrantLock dataLock = new ReentrantLock();
    private volatile MotionEvent currentMotionEvent = null;
    private HandlerThread sensorThread;
    private Handler sensorHandler;

    // 统一数据模型
    static class AllDataModel {
        private String touchType;
        private String touchDirection;
        private float x, y;
        private float pressure;
        private float size;
        private long time;
        private float accX, accY, accZ;
        private float gyroX, gyroY, gyroZ;
        private float magX, magY, magZ;
        private static final long serialVersionUID = 1L;

        public AllDataModel(
                String touchType, String touchDirection,
                float x, float y, float pressure, float size,
                long time,
                float accX, float accY, float accZ,
                float gyroX, float gyroY, float gyroZ,
                float magX, float magY, float magZ
        ) {
            this.touchType = touchType;
            this.touchDirection = touchDirection;
            this.x = x;
            this.y = y;
            this.pressure = pressure;
            this.size = size;
            this.time = time;
            this.accX = accX;
            this.accY = accY;
            this.accZ = accZ;
            this.gyroX = gyroX;
            this.gyroY = gyroY;
            this.gyroZ = gyroZ;
            this.magX = magX;
            this.magY = magY;
            this.magZ = magZ;
        }

        public String toDisplayText() {
            String formattedTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())
                    .format(new Date(time));
            return String.format("[%s] 时间: %s | 坐标: (%.1f, %.1f) | 压力: %.2f | 面积: %.2f | 方向: %s\n" +
                            "   加速度: (%.2f, %.2f, %.2f)\n   角速度: (%.2f, %.2f, %.2f)\n   磁场: (%.2f, %.2f, %.2f)\n",
                    touchType, formattedTime, x, y, pressure, size, touchDirection,
                    accX, accY, accZ, gyroX, gyroY, gyroZ, magX, magY, magZ);
        }

        public String toCsv() {
            // 用 %f 代替 %.1f、%.2f 等，不限制小数位数，保留 float 原始精度
            return String.format(Locale.ENGLISH, "%s,%f,%f,%d,%f,%f,%s," +
                            "%f,%f,%f,%f,%f,%f,%f,%f,%f",
                    touchType, x, y, time, pressure, size, touchDirection,
                    accX, accY, accZ, gyroX, gyroY, gyroZ, magX, magY, magZ);
        }

        public long getTime() {
            return time;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            AllDataModel that = (AllDataModel) o;
            return time == that.time &&
                    Float.compare(that.x, x) == 0 &&
                    Float.compare(that.y, y) == 0 &&
                    Float.compare(that.pressure, pressure) == 0 &&
                    Float.compare(that.size, size) == 0 &&
                    Float.compare(that.accX, accX) == 0 &&
                    Float.compare(that.accY, accY) == 0 &&
                    Float.compare(that.accZ, accZ) == 0 &&
                    Float.compare(that.gyroX, gyroX) == 0 &&
                    Float.compare(that.gyroY, gyroY) == 0 &&
                    Float.compare(that.gyroZ, gyroZ) == 0 &&
                    Float.compare(that.magX, magX) == 0 &&
                    Float.compare(that.magY, magY) == 0 &&
                    Float.compare(that.magZ, magZ) == 0 &&
                    touchType.equals(that.touchType) &&
                    touchDirection.equals(that.touchDirection);
        }

        @Override
        public int hashCode() {
            int result = Long.hashCode(time);
            result = 31 * result + touchType.hashCode();
            result = 31 * result + touchDirection.hashCode();
            result = 31 * result + Float.floatToIntBits(x);
            result = 31 * result + Float.floatToIntBits(y);
            result = 31 * result + Float.floatToIntBits(pressure);
            result = 31 * result + Float.floatToIntBits(size);
            result = 31 * result + Float.floatToIntBits(accX);
            result = 31 * result + Float.floatToIntBits(accY);
            result = 31 * result + Float.floatToIntBits(accZ);
            result = 31 * result + Float.floatToIntBits(gyroX);
            result = 31 * result + Float.floatToIntBits(gyroY);
            result = 31 * result + Float.floatToIntBits(gyroZ);
            result = 31 * result + Float.floatToIntBits(magX);
            result = 31 * result + Float.floatToIntBits(magY);
            result = 31 * result + Float.floatToIntBits(magZ);
            return result;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 初始化崩溃日志路径
        initCrashLogPath();
        // 注册全局异常捕获（捕获所有线程崩溃）
        registerGlobalCrashHandler();

        // 绑定控件
        mainContainer = findViewById(R.id.main_container);
        btnStart = findViewById(R.id.btnStart);
        btnStop = findViewById(R.id.btnStop);
        btnReset = findViewById(R.id.btnReset);
        btnDelete = findViewById(R.id.btnDelete);
        tvData = findViewById(R.id.tvData);
        tvScore = findViewById(R.id.tvScore);
        gameContainer = findViewById(R.id.gameContainer);
        spinnerFrequency = findViewById(R.id.spinnerFrequency);

        // 初始化传感器和频率选项
        initSensors();
        initFrequencySpinner();

        // 初始化游戏框尺寸并启动游戏
        gameContainer.post(() -> {
            int screenWidth = getResources().getDisplayMetrics().widthPixels;
            int gameSize = (int) (screenWidth * 0.9);
            LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) gameContainer.getLayoutParams();
            params.width = gameSize;
            params.height = gameSize;
            gameContainer.setLayoutParams(params);
            initGame();
        });

        // 按钮事件
        btnStart.setOnClickListener(v -> startCollect());
        btnStop.setOnClickListener(v -> stopCollect());
        btnReset.setOnClickListener(v -> {
            initGame();
            totalScore = 0;
            tvScore.setText("得分: 0");
        });
        btnDelete.setOnClickListener(v -> deleteCurrentData());

        // 触摸事件
        gameContainer.setOnTouchListener((v, event) -> {
            handleTouchEvent(event);
            handleGameSlide(event);
            return true;
        });
    }

    // 初始化崩溃日志保存路径
    private void initCrashLogPath() {
        File logDir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS + "/crash_logs");
        if (logDir != null && !logDir.exists()) {
            logDir.mkdirs();
        }
        crashLogPath = new File(logDir, "crash_log_" + new SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(new Date()) + ".txt").getAbsolutePath();
    }

    // 注册全局异常捕获器
    private void registerGlobalCrashHandler() {
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            // 保存崩溃日志到文件
            saveCrashLog(thread, throwable);
            // 让系统默认处理（正常退出应用）
            Thread.getDefaultUncaughtExceptionHandler().uncaughtException(thread, throwable);
        });
    }

    // 保存崩溃日志到本地文件（修改：统一UTF-8编码）
    private void saveCrashLog(Thread thread, Throwable throwable) {
        if (crashLogPath == null) return;

        String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault()).format(new Date());
        StringBuilder log = new StringBuilder();
        log.append("=== 崩溃时间：").append(time).append(" ===\n");
        log.append("崩溃线程：").append(thread.getName()).append("(tid:").append(thread.getId()).append(")\n");
        log.append("崩溃原因：").append(throwable.getMessage()).append("\n");
        log.append("堆栈信息：\n");
        for (StackTraceElement element : throwable.getStackTrace()) {
            log.append("\t").append(element.toString()).append("\n");
        }
        log.append("=========================================\n\n");

        // 追加写入日志文件：使用OutputStreamWriter指定UTF-8编码
        try (BufferedWriter writer = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(crashLogPath, true), StandardCharsets.UTF_8),
                8192)) {
            writer.write(log.toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void initGame() {
        if (gameManager != null) {
            gameManager = null;
        }
        gameManager = new GameManager(this, gameContainer);
        gameManager.setOnGameUpdateListener(addedScore -> {
            totalScore += addedScore;
            tvScore.setText("得分: " + totalScore);
        });
        gameManager.initAfterMeasure();
    }

    private void initSensors() {
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
        gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

        int accMaxFreq = getSensorMaxFrequency(accelerometer);
        int gyroMaxFreq = getSensorMaxFrequency(gyroscope);
        int magMaxFreq = getSensorMaxFrequency(magnetometer);
        int deviceMaxFreq = Math.min(Math.min(accMaxFreq, gyroMaxFreq), magMaxFreq);
        tvData.append("设备最大支持频率：" + deviceMaxFreq + "Hz（传感器最小值）\n");

        for (int hz : FIXED_HZ_OPTIONS) {
            if (hz <= deviceMaxFreq) {
                supportedHzList.add(hz);
            }
        }
        if (supportedHzList.isEmpty()) {
            supportedHzList.add(5);
        }

        // 初始化传感器线程（添加异常捕获）
        sensorThread = new HandlerThread("SensorThread") {
            @Override
            public void run() {
                try {
                    super.run(); // 执行原有Looper逻辑
                } catch (Throwable t) {
                    // 捕获子线程未处理异常，保存日志
                    saveCrashLog(Thread.currentThread(), t);
                }
            }
        };
        sensorThread.start();
        sensorHandler = new Handler(sensorThread.getLooper());
    }

    private void initFrequencySpinner() {
        List<String> displayOptions = new ArrayList<>();
        for (int hz : supportedHzList) {
            displayOptions.add(hz + " Hz");
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, displayOptions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFrequency.setAdapter(adapter);

        int defaultPos = supportedHzList.indexOf(50);
        if (defaultPos == -1) {
            defaultPos = supportedHzList.size() - 1;
        }
        spinnerFrequency.setSelection(defaultPos);
        selectedHz = supportedHzList.get(defaultPos);
        sensorDelay = 1000000 / selectedHz;

        spinnerFrequency.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedHz = supportedHzList.get(position);
                sensorDelay = 1000000 / selectedHz;
                tvData.append("已选择：" + selectedHz + "Hz（延迟：" + sensorDelay + "微秒）\n");
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    // 传感器监听器（核心优化：加锁+全程异常捕获）
    private final SensorEventListener sensorListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            // 捕获所有异常，避免子线程崩溃
            try {
                if (!isCollecting || isBatchSaving) return;
                if (event == null || event.values == null) return;

                dataLock.lock(); // 加锁：避免与保存线程冲突
                try {
                    // 限制数据最大条数，超过则删除最早数据
                    if (dataList.size() >= MAX_DATA_SIZE) {
                        dataList.remove(0);
                    }

                    // 达到批次阈值，触发自动保存（提交到UI线程执行）
                    if (dataList.size() >= BATCH_SAVE_SIZE) {
                        runOnUiThread(() -> {
                            if (isCollecting && !isBatchSaving) {
                                batchSaveData();
                            }
                        });
                        return;
                    }
                } finally {
                    dataLock.unlock(); // 确保锁一定释放
                }

                // 解析传感器数据
                float accX = 0, accY = 0, accZ = 0;
                float gyroX = 0, gyroY = 0, gyroZ = 0;
                float magX = 0, magY = 0, magZ = 0;

                switch (event.sensor.getType()) {
                    case Sensor.TYPE_LINEAR_ACCELERATION:
                        accX = event.values[0];
                        accY = event.values[1];
                        accZ = event.values[2];
                        break;
                    case Sensor.TYPE_GYROSCOPE:
                        gyroX = event.values[0];
                        gyroY = event.values[1];
                        gyroZ = event.values[2];
                        break;
                    case Sensor.TYPE_MAGNETIC_FIELD:
                        magX = event.values[0];
                        magY = event.values[1];
                        magZ = event.values[2];
                        break;
                }

                // 安全获取触摸数据（避免currentMotionEvent为空）
                float touchX = 0f, touchY = 0f, pressure = 0f, size = 0f;
                if (currentMotionEvent != null && currentTouchType.equals("滑动中")) {
                    try {
                        pressure = currentMotionEvent.getPressure();
                        size = currentMotionEvent.getSize();
                        touchX = currentMotionEvent.getRawX();
                        touchY = currentMotionEvent.getRawY();
                    } catch (Exception e) {
                        // 触摸事件异常时使用默认值，不中断采集
                        pressure = currentPressure;
                        size = currentSize;
                        touchX = currentTouchX;
                        touchY = currentTouchY;
                    }
                } else {
                    touchX = currentTouchType.equals("无触摸") ? 0 : currentTouchX;
                    touchY = currentTouchType.equals("无触摸") ? 0 : currentTouchY;
                    pressure = currentPressure;
                    size = currentSize;
                }

                // 创建数据模型（所有参数安全赋值）
                AllDataModel data = new AllDataModel(
                        currentTouchType != null ? currentTouchType : "无触摸",
                        currentTouchDirection != null ? currentTouchDirection : "无",
                        touchX, touchY, pressure, size,
                        System.currentTimeMillis(),
                        accX, accY, accZ, gyroX, gyroY, gyroZ, magX, magY, magZ
                );

                // 安全添加数据到列表
                dataLock.lock();
                try {
                    dataList.add(data);
                } finally {
                    dataLock.unlock();
                }

            } catch (Throwable t) {
                // 捕获所有异常，记录日志并继续采集
                t.printStackTrace();
                String errorMsg = "传感器采集异常：" + t.getMessage();
                runOnUiThread(() -> tvData.append(errorMsg + "\n"));
                saveCrashLog(Thread.currentThread(), t);
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {}
    };

    // 触摸事件处理（添加异常捕获）
    private void handleTouchEvent(MotionEvent event) {
        if (event == null) return;
        try {
            long time = System.currentTimeMillis();
            float rawX = event.getRawX();
            float rawY = event.getRawY();

            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    currentTouchType = "按下";
                    currentTouchDirection = "无";
                    currentTouchX = rawX;
                    currentTouchY = rawY;
                    currentPressure = event.getPressure();
                    currentSize = event.getSize();
                    currentTouchStart = time;
                    // 安全赋值：使用 MotionEvent.obtain 避免原事件被回收
                    currentMotionEvent = MotionEvent.obtain(event);
                    tvData.append("按下：压力=" + currentPressure + ", 面积=" + currentSize + "\n");
                    break;

                case MotionEvent.ACTION_MOVE:
                    currentTouchType = "滑动中";
                    currentTouchX = rawX;
                    currentTouchY = rawY;
                    currentPressure = event.getPressure();
                    currentSize = event.getSize();
                    currentMotionEvent = MotionEvent.obtain(event);
                    break;

                case MotionEvent.ACTION_UP:
                    currentTouchType = "抬起";
                    currentTouchDirection = getSlideDirection(event.getX(), event.getY());
                    currentTouchX = rawX;
                    currentTouchY = rawY;
                    currentPressure = event.getPressure();
                    currentSize = event.getSize();
                    // 安全添加触摸间隔
                    dataLock.lock();
                    try {
                        allTouchIntervals.add(new long[]{currentTouchStart, time});
                    } finally {
                        dataLock.unlock();
                    }
                    currentMotionEvent = null;
                    tvData.append("抬起：压力=" + currentPressure + ", 面积=" + currentSize + ", 方向=" + currentTouchDirection + "\n");

                    mainContainer.postDelayed(() -> {
                        currentTouchType = "无触摸";
                        currentTouchDirection = "无";
                        currentTouchX = 0f;
                        currentTouchY = 0f;
                        currentPressure = 0f;
                        currentSize = 0f;
                    }, 30);
                    break;

                default:
                    currentTouchType = "无触摸";
                    currentMotionEvent = null;
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
            tvData.append("触摸事件处理异常：" + e.getMessage() + "\n");
            saveCrashLog(Thread.currentThread(), e);
        }
    }

    // 游戏滑动逻辑（添加异常捕获）
    private void handleGameSlide(MotionEvent event) {
        if (event == null) return;
        try {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    touchStartX = event.getX();
                    touchStartY = event.getY();
                    break;
                case MotionEvent.ACTION_UP:
                    getSlideDirection(event.getX(), event.getY());
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
            tvData.append("游戏滑动处理异常：" + e.getMessage() + "\n");
        }
    }

    private String getSlideDirection(float endX, float endY) {
        float dx = endX - touchStartX;
        float dy = endY - touchStartY;

        if (Math.abs(dx) > Math.abs(dy)) {
            if (Math.abs(dx) > dpToPx(MIN_SLIDE_DISTANCE)) {
                GameManager.Direction dir = dx > 0 ? GameManager.Direction.RIGHT : GameManager.Direction.LEFT;
                if (gameManager != null) {
                    gameManager.slide(dir);
                }
                return dx > 0 ? "右滑" : "左滑";
            }
        } else {
            if (Math.abs(dy) > dpToPx(MIN_SLIDE_DISTANCE)) {
                GameManager.Direction dir = dy > 0 ? GameManager.Direction.DOWN : GameManager.Direction.UP;
                if (gameManager != null) {
                    gameManager.slide(dir);
                }
                return dy > 0 ? "下滑" : "上滑";
            }
        }
        return "无效滑动";
    }

    // 开始收集（生成唯一文件标识）
    private void startCollect() {
        isCollecting = true;
        // 加锁清空数据
        dataLock.lock();
        try {
            dataList.clear();
            allTouchIntervals.clear();
        } finally {
            dataLock.unlock();
        }
        currentTouchType = "无触摸";

        // 生成收集会话ID和目标文件路径
        collectSessionId = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        File csvDir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
        targetCsvPath = new File(csvDir, "2048_AllData_" + collectSessionId + ".csv").getAbsolutePath();

        tvData.setText("开始收集（" + selectedHz + "Hz）...\n目标文件：" + targetCsvPath + "\n");

        // 注册传感器（安全注册，避免重复）
        if (!isSensorRegistered) {
            try {
                if (accelerometer != null) {
                    sensorManager.registerListener(sensorListener, accelerometer, sensorDelay, sensorHandler);
                }
                if (gyroscope != null) {
                    sensorManager.registerListener(sensorListener, gyroscope, sensorDelay, sensorHandler);
                }
                if (magnetometer != null) {
                    sensorManager.registerListener(sensorListener, magnetometer, sensorDelay, sensorHandler);
                }
                isSensorRegistered = true;
            } catch (Exception e) {
                e.printStackTrace();
                tvData.append("传感器注册失败：" + e.getMessage() + "\n");
                Toast.makeText(this, "传感器注册失败", Toast.LENGTH_SHORT).show();
            }
        }

        btnStart.setEnabled(false);
        btnStop.setEnabled(true);
    }

    // 停止收集（保存剩余数据，重置会话）
    private void stopCollect() {
        isCollecting = false;
        // 注销传感器
        if (isSensorRegistered) {
            try {
                sensorManager.unregisterListener(sensorListener);
                isSensorRegistered = false;
            } catch (Exception e) {
                e.printStackTrace();
                tvData.append("传感器注销失败：" + e.getMessage() + "\n");
            }
        }

        // 获取剩余数据量（加锁）
        int remainingSize = 0;
        dataLock.lock();
        try {
            remainingSize = dataList.size();
        } finally {
            dataLock.unlock();
        }
        tvData.append("收集停止，剩余" + remainingSize + "条数据待保存\n");

        // 保存剩余数据到同一文件
        if (remainingSize > 0) {
            manualSaveData();
        }

        // 重置会话标识，下次收集生成新文件
        collectSessionId = null;
        targetCsvPath = null;

        btnStart.setEnabled(true);
        btnStop.setEnabled(false);
    }

    // 手动保存（用户触发）
    private void manualSaveData() {
        if (targetCsvPath == null) {
            Toast.makeText(this, "未开始收集", Toast.LENGTH_SHORT).show();
            return;
        }
        saveDataImpl(false, targetCsvPath);
    }

    // 分批次自动保存（阈值触发）
    private void batchSaveData() {
        saveDataImpl(true, targetCsvPath);
    }

    // 保存数据核心实现（追加到同一文件，加锁保证线程安全）
    private void saveDataImpl(boolean isBatch, String targetCsvPath) {
        // 加锁获取当前数据（避免保存期间数据变化）
        List<AllDataModel> tempDataList = new ArrayList<>();
        List<long[]> tempTouchIntervals = new ArrayList<>();

        dataLock.lock();
        try {
            if (dataList.isEmpty()) {
                if (!isBatch) {
                    Toast.makeText(this, "无数据可保存", Toast.LENGTH_SHORT).show();
                }
                return;
            }
            tempDataList.addAll(dataList);
            tempTouchIntervals.addAll(allTouchIntervals);

            // 自动保存时清空列表，继续收集新数据
            if (isBatch) {
                dataList.clear();
                allTouchIntervals.clear();
            }
        } finally {
            dataLock.unlock();
        }

        isBatchSaving = true;

        if (isBatch) {
            tvData.append("分批次保存（" + tempDataList.size() + "条），追加到目标文件...\n");
        } else {
            tvData.append("手动保存（" + tempDataList.size() + "条），追加到目标文件...\n");
        }

        // 创建临时文件存储当前批次数据
        File tempDir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS + "/temp");
        if (tempDir == null) {
            tvData.append("保存失败：无法创建临时目录\n");
            isBatchSaving = false;
            return;
        }
        if (!tempDir.exists()) {
            tempDir.mkdirs();
        }

        String tempFileName = "temp_data_" + System.currentTimeMillis() + ".json";
        File tempFile = new File(tempDir, tempFileName);

        // 写入临时文件（修改：统一使用StandardCharsets.UTF_8）
        Gson gson = new Gson();
        try (BufferedWriter writer = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(tempFile), StandardCharsets.UTF_8))) {
            writer.write(gson.toJson(tempDataList, new TypeToken<List<AllDataModel>>() {}.getType()) + "\n");
            writer.write(gson.toJson(tempTouchIntervals, new TypeToken<List<long[]>>() {}.getType()));
        } catch (IOException e) {
            tvData.append("保存准备失败：" + e.getMessage() + "\n");
            e.printStackTrace();
            isBatchSaving = false;
            return;
        }

        // 传递参数给Worker
        Data inputData = new Data.Builder()
                .putString("tempFilePath", tempFile.getAbsolutePath())
                .putLong("filterTimeT", FILTER_TIME_T)
                .putBoolean("isBatch", isBatch)
                .putString("targetCsvPath", targetCsvPath) // 目标文件路径
                .build();

        OneTimeWorkRequest saveRequest = new OneTimeWorkRequest.Builder(SaveAllDataWorker.class)
                .setInputData(inputData)
                .build();

        WorkManager.getInstance(this).enqueue(saveRequest);
        WorkManager.getInstance(this)
                .getWorkInfoByIdLiveData(saveRequest.getId())
                .observe(this, workInfo -> {
                    if (workInfo != null) {
                        if (workInfo.getState() == WorkInfo.State.SUCCEEDED) {
                            tvData.append((isBatch ? "分批次" : "手动") + "保存成功：数据已追加到目标文件\n");
                            if (!isBatch) {
                                // 手动保存成功后清空数据（加锁）
                                dataLock.lock();
                                try {
                                    dataList.clear();
                                    allTouchIntervals.clear();
                                } finally {
                                    dataLock.unlock();
                                }
                            }
                            // 清理临时文件
                            if (tempFile.exists()) {
                                tempFile.delete();
                            }
                        } else if (workInfo.getState() == WorkInfo.State.FAILED) {
                            String error = workInfo.getOutputData().getString("error") != null ?
                                    workInfo.getOutputData().getString("error") : "未知错误";
                            tvData.append((isBatch ? "分批次" : "手动") + "保存失败：" + error + "\n");
                        }
                        isBatchSaving = false;
                    }
                });

        if (!isBatch) {
            Toast.makeText(this, "保存中...", Toast.LENGTH_SHORT).show();
        }
    }

    // 删除当前数据（加锁保证安全）
    private void deleteCurrentData() {
        dataLock.lock();
        try {
            dataList.clear();
            allTouchIntervals.clear();
        } finally {
            dataLock.unlock();
        }
        tvData.setText("当前数据已删除\n");
        Toast.makeText(this, "已删除", Toast.LENGTH_SHORT).show();
    }

    // dp转px
    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    // 检测传感器最大支持频率
    private int getSensorMaxFrequency(Sensor sensor) {
        if (sensor == null) return 5;
        float minDelay = sensor.getMinDelay();
        if (minDelay <= 0) return 50;
        int maxFreq = (int) (1000000 / minDelay);
        return Math.max(5, Math.min(maxFreq, 100));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        isCollecting = false;
        isBatchSaving = false;

        // 安全注销传感器
        if (sensorManager != null && isSensorRegistered) {
            try {
                sensorManager.unregisterListener(sensorListener);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // 安全停止传感器线程
        if (sensorThread != null) {
            sensorThread.quitSafely();
            try {
                sensorThread.join(1000); // 等待线程退出
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // 清空数据（加锁）
        dataLock.lock();
        try {
            dataList.clear();
            allTouchIntervals.clear();
        } finally {
            dataLock.unlock();
        }

        currentMotionEvent = null;
    }

    // 保存数据的Worker（支持追加写入同一文件，增强异常处理）
    public static class SaveAllDataWorker extends Worker {
        public SaveAllDataWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
            super(context, workerParams);
        }

        @NonNull
        @Override
        public Result doWork() {
            try {
                Data inputData = getInputData();
                String tempFilePath = inputData.getString("tempFilePath");
                long FILTER_TIME_T = inputData.getLong("filterTimeT", 500);
                String targetCsvPath = inputData.getString("targetCsvPath");

                // 参数校验
                if (tempFilePath == null || targetCsvPath == null) {
                    return Result.failure(new Data.Builder().putString("error", "参数缺失").build());
                }
                File tempFile = new File(tempFilePath);
                if (!tempFile.exists()) {
                    return Result.failure(new Data.Builder().putString("error", "临时文件不存在").build());
                }
                File targetCsvFile = new File(targetCsvPath);

                // 读取临时文件数据（修改：统一使用StandardCharsets.UTF_8，移除GBK兼容）
                List<String> lines = Files.readAllLines(tempFile.toPath(), StandardCharsets.UTF_8);

                if (lines.size() < 2) {
                    return Result.failure(new Data.Builder().putString("error", "临时文件格式错误").build());
                }

                Gson gson = new Gson();
                List<AllDataModel> dataList = gson.fromJson(lines.get(0), new TypeToken<List<AllDataModel>>() {}.getType());
                List<long[]> allTouchIntervals = gson.fromJson(lines.get(1), new TypeToken<List<long[]>>() {}.getType());

                if (dataList == null || dataList.isEmpty()) {
                    return Result.failure(new Data.Builder().putString("error", "解析后数据为空").build());
                }

                // 过滤、去重、排序（优化去重逻辑，提升效率）
                List<AllDataModel> filteredData = new ArrayList<>();
                if (allTouchIntervals != null && !allTouchIntervals.isEmpty()) {
                    for (long[] interval : allTouchIntervals) {
                        long filterStart = interval[0] - FILTER_TIME_T;
                        long filterEnd = interval[1] + FILTER_TIME_T;
                        for (AllDataModel data : dataList) {
                            if (data.getTime() >= filterStart && data.getTime() <= filterEnd) {
                                // 优化去重：通过时间戳+坐标快速判断（避免遍历对比）
                                boolean isDuplicate = false;
                                for (int i = filteredData.size() - 1; i >= 0; i--) {
                                    AllDataModel existing = filteredData.get(i);
                                    if (existing.getTime() == data.getTime()
                                            && Math.abs(existing.x - data.x) < 0.1f
                                            && Math.abs(existing.y - data.y) < 0.1f) {
                                        isDuplicate = true;
                                        break;
                                    }
                                }
                                if (!isDuplicate) {
                                    filteredData.add(data);
                                }
                            }
                        }
                    }
                } else {
                    filteredData.addAll(dataList);
                }
                Collections.sort(filteredData, (d1, d2) -> Long.compare(d1.getTime(), d2.getTime()));

                // 追加写入目标文件（增强容错：文件不存在时自动创建父目录）
                if (!targetCsvFile.getParentFile().exists()) {
                    targetCsvFile.getParentFile().mkdirs();
                }

                // 写入目标文件（修改：统一使用StandardCharsets.UTF_8）
                try (FileOutputStream fos = new FileOutputStream(targetCsvFile, true); // 追加模式
                     BufferedWriter writer = new BufferedWriter(
                             new OutputStreamWriter(fos, StandardCharsets.UTF_8), 8192)) {

                    // 第一次保存：写入BOM头和表头
                    if (!targetCsvFile.exists()) {
                        fos.write(0xef); // UTF-8 BOM头（兼容Windows）
                        fos.write(0xbb);
                        fos.write(0xbf);
                        writer.write("事件类型,X坐标,Y坐标,时间戳(毫秒),压力,面积,滑动方向," +
                                "加速度X,加速度Y,加速度Z,角速度X,角速度Y,角速度Z,磁场X,磁场Y,磁场Z\n");
                    }

                    // 追加数据行（避免空指针）
                    for (AllDataModel data : filteredData) {
                        if (data != null) {
                            writer.write(data.toCsv() + "\n");
                        }
                    }
                }

                return Result.success();
            } catch (Exception e) {
                e.printStackTrace();
                return Result.failure(new Data.Builder().putString("error", "保存失败：" + e.getMessage()).build());
            }
        }
    }
}