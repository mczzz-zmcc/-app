pluginManagement {
    repositories {
        // 1. 优先官方仓库（TensorFlow依赖在这里）
        maven { url = uri("https://maven.aliyun.com/repository/google") }
        google()
        mavenCentral()
        // 2. 再用阿里云镜像（作为补充）
        maven { url = uri("https://maven.aliyun.com/repository/google") }
        maven { url = uri("https://maven.aliyun.com/repository/central") }
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        // 1. 优先官方仓库（关键！TensorFlow依赖在google()仓库）
        google()
        mavenCentral()
        // 2. 再用阿里云镜像
        maven { url = uri("https://maven.aliyun.com/repository/google") }
        maven { url = uri("https://maven.aliyun.com/repository/central") }
    }
}

rootProject.name = "AllData"
include(":app")
